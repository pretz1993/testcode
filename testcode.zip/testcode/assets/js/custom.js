jQuery(function() {

// ADDING A ROW FOR SQUARE SECTION	
	$('.circle-inner-wrapper .circle').click(function(){
		var datarel = $(this).attr('rel');

		$('#'+datarel).html('<div class="square '+datarel+'" rel="'+datarel+'" style="display:block;"><p>'+datarel+'</p></div>');
	});

// CHANGE COLOR ON FIRST ROW WHEN CLICK SQUARE ICON
	$('.square-wrapper .col-md-2').click(function(){
		var $this = $(this);
  		$this.prependTo('.square-outer-wrapper');
  		$(this).children().children().hide();
		var idthis = $(this).attr('id');
		var $this = $(this).parent().parent().parent().siblings('.circle-wrapper').children().children('.circle-outer-wrapper').children('#'+idthis);
  		$this.prependTo('.circle-outer-wrapper');
	});
});

// OPACITY TO 50% WHEN HOVER
 $('.circle-wrapper .col-md-2').hover(			
   	function () {
      	$(this).css('opacity','1');
		$(this).siblings().css('opacity','0.5');
   }, 
	
   function () {
      	$(this).css('opacity','1');
		$(this).siblings().css('opacity','1');
   }
);

$('.square-wrapper .col-md-2').hover(			
   	function () {
      	$(this).css('opacity','1');
		$(this).siblings().css('opacity','0.5');
   }, 
	
   function () {
      	$(this).css('opacity','1');
		$(this).siblings().css('opacity','1');
   }
);